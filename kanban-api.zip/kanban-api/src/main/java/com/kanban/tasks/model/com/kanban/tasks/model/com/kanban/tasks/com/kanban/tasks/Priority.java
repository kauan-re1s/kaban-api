package com.kanban.tasks.model;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH
}
