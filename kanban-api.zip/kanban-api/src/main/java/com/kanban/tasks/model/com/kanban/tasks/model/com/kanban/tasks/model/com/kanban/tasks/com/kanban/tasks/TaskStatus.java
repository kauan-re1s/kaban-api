package com.kanban.tasks.model;

public enum TaskStatus {
    TO_DO,
    IN_PROGRESS,
    DONE
}